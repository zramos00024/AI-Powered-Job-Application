# Job Application Agent (shareable kit)

Files: `PLAYBOOK.md` (agent instructions, same for everyone), `profile.template.md` (each person's settings), `deliver.ps1` (Windows Desktop delivery), `test-deliver.ps1` (self-check).

## Setup (per friend, ~15 min)
1. Copy `profile.template.md` to `profile.md`, fill it in, and put it with the master resume in a private folder. Never share your filled-in profile.
2. Create a cloud-synced outbox folder (OneDrive/Google Drive for desktop), e.g. `OneDrive\JobApplications`, and set it in the profile.
3. In Claude, connect YOUR Gmail, then create a scheduled task that runs every few hours with this prompt: *"Follow PLAYBOOK.md using profile.md."* Add morning and evening summary times from your profile.
4. On the Windows laptop, once: `.\deliver.ps1 -Outbox "<your outbox>" -Install`.
5. Folders appear on your Desktop. Review, edit, submit yourself, then reply "applied: <company>" or "skip: <company>" to the summary email.

Delivery waits by design: the agent writes to the synced outbox, and the helper copies new folders whenever the laptop is on and synced.

Not covered: sending applications (manual by design), non-LinkedIn alerts, and macOS delivery.
