# Setup guide for a new applicant (about 30 minutes)

You need: a Windows laptop, the Claude desktop app (signed in), your own Gmail, a LinkedIn account, and Google Drive for desktop (or OneDrive). Do every step with YOUR OWN accounts. Never use someone else's profile, resume or Gmail.

## 1. Get the kit
Copy the `JobAgent-Share` folder to `Documents\JobAgent`. It contains: PLAYBOOK.md, profile.template.md, deliver.ps1, make_docx.py, test-deliver.ps1, README.md. Python 3 must be installed (python.org, tick "Add to PATH").

## 2. LinkedIn job alerts
On LinkedIn go to Jobs, search for your target roles (for example "operations manager" or "head of delivery"), set location and Remote/Hybrid, then switch on **Get alerts** with email, **every few hours or daily**. Make sure alerts go to the Gmail you will connect to Claude.

## 3. Fill in your profile
1. Copy `profile.template.md` to `profile.md`.
2. Fill in every line. If you do not want to type, give Claude your resume file and ask it to fill the profile for you.
3. Put your master resume (.docx) in the same folder and write its path in the profile.
4. Achievement examples are the most important part. For a manager, include team size, budget, targets hit, cost or time saved, projects delivered, and people you promoted. The agent never invents numbers, so real figures make strong drafts.
5. Set your timezone (e.g. Australia/Sydney), summary times (e.g. 08:00 / 18:00) and your seniority (e.g. Senior Manager, Head of).

## 4. Make the outbox
In Google Drive for desktop make a folder `JobApplications` and write its full path (for example `G:\My Drive\JobApplications`) in the profile.

## 5. Install the Desktop helper (once)
Open PowerShell:
```
cd "$env:USERPROFILE\Documents\JobAgent"
.\deliver.ps1 -Outbox "G:\My Drive\JobApplications" -Install
```
If scripts are blocked, run `Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` first. Test it with `.\test-deliver.ps1` (should print PASS).

## 6. Connect Gmail
In the Claude app, Settings, Connectors: connect your own Gmail.

## 7. First test run
In Claude, open the `JobAgent` folder and say: *"Follow PLAYBOOK.md using profile.md."* Check that a folder appears in the outbox, then on your Desktop, with all 8 files. Read the checklist and tell Claude what to change.

## 8. Schedule it
In Claude, ask: *"Create two scheduled tasks for me: one at 08:00 and 18:00 that runs PLAYBOOK.md with profile.md and emails me the summary, and one every 3 hours that runs it without email."* Use your own name, folder paths and email. The computer must be on and the Claude app open for runs to happen.

## 9. Every day
Read the summary email. Open the folders on your Desktop, edit, and apply yourself on LinkedIn. Then reply `applied: <company>` or `skip: <company>` to the summary email.

## Changing the role later
Edit `profile.md` only: Target roles, Industries, Locations, Seniority, Work arrangement. The playbook works for any role. Then update your LinkedIn alerts to match.
