# Applicant Profile (copy to profile.md and fill in; keep private, never share)

## Identity and evidence
- Applicant name: 
- Email / phone / city / LinkedIn URL: 
- Master resume (path or link): 
- LinkedIn profile (saved PDF/export path or link): 
- Achievement examples (situation, action, measurable result; add as many as you can):
  1. 

## Job preferences
- Target roles: 
- Industries (include / exclude): 
- Locations: 
- Seniority: 
- Work arrangement (remote / hybrid / onsite): 
- Min fit score to draft (0-10, default 6): 

## Document preferences
- CV template (path): 
- Writing tone (e.g. warm and direct, formal): 
- CV length (pages): 
- Cover letter length (words): 

## Connections
- Gmail account that receives LinkedIn alerts: 
- LinkedIn alert sender/subject patterns (optional): 

## Notifications
- Summary email address: 
- Timezone (IANA, e.g. Australia/Sydney): 
- Morning time / evening time (e.g. 08:00 / 18:00): 

## Delivery
- Outbox (cloud-synced folder the agent writes to, e.g. OneDrive\JobApplications): 
- Desktop folder (default: Windows Desktop): 
