$ErrorActionPreference = 'Stop'
$t = Join-Path ([IO.Path]::GetTempPath()) "deliver-test-$(Get-Random)"
$out = "$t\out"; $desk = "$t\desk"
New-Item -ItemType Directory "$out\A - Dev - 01-01-2026", "$out\B - Dev - 02-01-2026", $desk | Out-Null
'x' | Set-Content "$out\A - Dev - 01-01-2026\job-description.md"; '' | Set-Content "$out\A - Dev - 01-01-2026\.complete"; 'Acme' | Set-Content "$out\A - Dev - 01-01-2026\.company"
New-Item -ItemType Directory "$desk\A - Dev - 01-01-2026" | Out-Null   # pre-existing clash

& "$PSScriptRoot\deliver.ps1" -Outbox $out -Desktop $desk | Out-Null
& "$PSScriptRoot\deliver.ps1" -Outbox $out -Desktop $desk | Out-Null   # second run must not redeliver

$d = (Get-ChildItem $desk -Directory).Name
if ($d -notcontains 'A - Dev - 01-01-2026 - Acme') { throw "clash not renamed: $d" }
if ($d -contains 'B - Dev - 02-01-2026') { throw 'incomplete folder was delivered' }
if ($d.Count -ne 2) { throw "redelivered: $d" }
if (-not (Test-Path "$out\A - Dev - 01-01-2026\.delivered")) { throw 'no .delivered marker' }
if (Test-Path "$desk\A - Dev - 01-01-2026 - Acme\.complete") { throw 'marker leaked to Desktop' }
Remove-Item $t -Recurse -Force
Write-Host 'PASS'
