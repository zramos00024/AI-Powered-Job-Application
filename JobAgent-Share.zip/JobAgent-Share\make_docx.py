"""Plain-text to .docx with the standard library only.
Usage: python make_docx.py input.txt output.docx
Line syntax: '# ' title, '## ' section heading, '- ' bullet, blank line = gap, anything else = paragraph.
"""
import sys, zipfile
from xml.sax.saxutils import escape

CT = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/></Types>'
RELS = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'
W = 'xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"'


def para(text, size=21, bold=False, bullet=False, after=60):
    ind = '<w:ind w:left="360" w:hanging="240"/>' if bullet else ''
    text = ('• ' + text) if bullet else text
    b = '<w:b/>' if bold else ''
    return (f'<w:p><w:pPr><w:spacing w:after="{after}"/>{ind}</w:pPr><w:r><w:rPr>{b}'
            f'<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:sz w:val="{size}"/></w:rPr>'
            f'<w:t xml:space="preserve">{escape(text)}</w:t></w:r></w:p>')


def build(lines):
    out = []
    for ln in lines:
        ln = ln.rstrip('\n')
        if ln.startswith('## '): out.append(para(ln[3:].upper(), 22, True, after=80))
        elif ln.startswith('# '): out.append(para(ln[2:], 32, True, after=40))
        elif ln.startswith('- '): out.append(para(ln[2:], bullet=True))
        elif not ln.strip(): out.append(para('', 10, after=0))
        else: out.append(para(ln))
    return (f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><w:document {W}><w:body>'
            + ''.join(out) + '<w:sectPr><w:pgMar w:top="900" w:right="1000" w:bottom="900" w:left="1000"/></w:sectPr></w:body></w:document>')


if __name__ == '__main__':
    src, dst = sys.argv[1], sys.argv[2]
    with open(src, encoding='utf-8') as f:
        doc = build(f.readlines())
    with zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', CT)
        z.writestr('_rels/.rels', RELS)
        z.writestr('word/document.xml', doc)
