# Moves finished application folders from the synced outbox to the Desktop.
#   .\deliver.ps1 -Outbox "$env:USERPROFILE\OneDrive\JobApplications"          # run once
#   .\deliver.ps1 -Outbox "..." -Install                                      # run at logon + every 15 min
param(
    [Parameter(Mandatory)][string]$Outbox,
    [string]$Desktop = [Environment]::GetFolderPath('Desktop'),
    [switch]$Install
)
$ErrorActionPreference = 'Stop'

if ($Install) {
    $self = $MyInvocation.MyCommand.Path
    $act  = New-ScheduledTaskAction -Execute 'powershell.exe' -Argument "-NoProfile -WindowStyle Hidden -File `"$self`" -Outbox `"$Outbox`" -Desktop `"$Desktop`""
    $trg  = @((New-ScheduledTaskTrigger -AtLogOn), (New-ScheduledTaskTrigger -Once -At (Get-Date) -RepetitionInterval (New-TimeSpan -Minutes 15)))
    Register-ScheduledTask -TaskName 'JobApplicationDelivery' -Action $act -Trigger $trg -Force | Out-Null
    Write-Host 'Installed. Runs at logon and every 15 minutes (missed runs happen once the laptop is back on).'
    return
}

# .complete is written last by the agent, so half-synced folders are skipped.
Get-ChildItem $Outbox -Directory | Where-Object {
    (Test-Path (Join-Path $_.FullName '.complete')) -and -not (Test-Path (Join-Path $_.FullName '.delivered'))
} | ForEach-Object {
    $dest = Join-Path $Desktop $_.Name
    if (Test-Path $dest) {
        $companyFile = Join-Path $_.FullName '.company'
        $company = if (Test-Path $companyFile) { (Get-Content $companyFile -Raw).Trim() } else { Get-Date -Format 'HHmmss' }
        $dest = "$dest - $company"
        $n = 2
        while (Test-Path $dest) { $dest = "$dest ($n)"; $n++ }
    }
    Copy-Item $_.FullName $dest -Recurse
    # Desktop copy must not carry the markers; the outbox copy keeps .delivered so the agent can report it.
    Remove-Item (Join-Path $dest '.complete'), (Join-Path $dest '.company'), (Join-Path $dest '.delivered') -Force -ErrorAction SilentlyContinue
    Set-Content (Join-Path $_.FullName '.delivered') (Get-Date -Format o)
    Write-Host "Delivered: $dest"
}
